import React, { useState } from "react";
import useSWR from "swr";
import "./App.scss";

const fetcher = (url) => fetch(url).then((res) => res.json());

const MTurkMap = {
  guessed: (data) => data.guessed_label,
  both: (data) => `${data.label} and ${data.guessed_label}`,
  neither: (data) => `neither ${data.label} not ${data.guessed_label}`,
};

function App() {
  const [sortCol, setSortCol] = useState();
  const [sortDirection, setSortDirection] = useState("asc");
  const [sortedData, setSortedData] = useState([]);

  let { data, error, isLoading } = useSWR(
    "https://labelerrors.com/api/data?dataset=ImageNet&page=1&limit=100",
    fetcher
  );
  if (isLoading) return <div>loading...</div>;
  if (error) return <div>failed to load</div>;
  if (data && !data.length) return <div>no data</div>;

  const cellData = (id, data) => {
    if (id === "path") {
      return <img src={"https://labelerrors.com/" + data[id]} />;
    }
    if (id === "mturk_info") {
      return MTurkMap[data[id]](data);
    }
    return data[id];
  };

  const sortFunction = (col, direction) => {
    let sortFn;
    if (col === "id") {
      if (direction === "asc") {
        sortFn = (a, b) => a[col] - b[col];
      } else {
        sortFn = (a, b) => b[col] - a[col];
      }
    } else {
      if (direction === "asc") {
        sortFn = (a, b) => a[col]?.localeCompare(b[col]);
      } else {
        sortFn = (a, b) => b[col]?.localeCompare(a[col]);
      }
    }
    return sortFn;
  };

  const onClickSort = (evt) => {
    const id = evt.currentTarget.id;
    let newId = sortCol,
      newDir = sortDirection;
    if (id === sortCol) {
      newDir = sortDirection === "asc" ? "desc" : "asc";
    } else {
      newDir = "asc";
      newId = id;
    }
    setSortDirection(newDir);
    setSortCol(newId);
    const newData = data.sort(sortFunction(newId, newDir));
    setSortedData(newData);
  };

  // const sortData = (col, direction) => {
  //   let sortFn = (a, b) => a[col] > b[col];
  //   if (col !== "id") {
  //     sortFn = (a, b) => a[col].localeCompare(b[col]);
  //   }
  //   return sortFn;
  // };

  if (data && !sortedData) {
    setSortedData(data);
    return <div>loading...</div>;
  }

  // Column headers
  const tableHeaders = data.length ? Object.keys(data[0]) : [];
  // Basic table scaffolding -- feel free to change whatever you like
  return (
    <table>
      <thead>
        {/* Table column headers */}
        <tr>
          {tableHeaders?.map((e) => (
            <th id={e} key={e} onClick={onClickSort}>
              {e} {e === sortCol ? sortDirection : ""}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {/* Table rows */}
        {data?.map((e) => (
          <tr key={e.id}>
            {tableHeaders.map((header) => (
              <td key={e[header]}>{cellData(header, e)}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default App;
